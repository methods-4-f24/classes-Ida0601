

# PYTHON SCRIPT:

#Installing packages/Importing modules
from psychopy import visual, core, event, gui, data
from glob import glob
import random
import pandas as pd
import ppc
import os
from triggers import setParallelData
 
#### Portfolio 3: Where the f is F? ####


# Defining window
win = visual.Window(color=(0, 0, 0), fullscr=False)

# Visual dot for check of stimulus in MEG
stimDot = visual.GratingStim(win, size=.5, tex=None, pos=(7, -6),
                             color=1, mask='circle', autoLog=False)

dur=int(0.7*60)
'''
Triggers:
    11 = Cars
    22 = Unknown faces
    33 = Famous Faces
    44 = Personally known faces
    100 = C key press for "Car"
    200 = F key press for "face"
    99 = Correct response
    1 =  Incorrect response 
'''
### function for showing picture for experiment
def pic_and_react(stimulus, stop_watch):
    
    if stimulus[20:24] == "CARS":
        image_trigger = "11"
    elif stimulus[20:24] == "RAND":
        image_trigger = "22"
    elif stimulus[20:24] == "FAME":
        image_trigger = "33"
    else: image_trigger = "44"
    
    #Set MEG trigger in off state
    pullTriggerDown = False
    
    #set delay to a random chice between chosen values
    delay=random.choice([0.4, 0.9])
    # wait for another 1 second (how long is the black screen)
    core.wait(delay)
    
    pic = visual.ImageStim(win, image = stimulus)
    
    time_flip_img=core.monotonicClock.getTime() #onset of stimulus
    event.clearEvents(eventType='keyboard')# clear keyboard input to make sure that no responses are logged that do not belong to stimulus
    for frame in range(10):
        pic.draw()
        stimDot.draw()
        if frame == 1:
            win.callOnFlip(setParallelData, image_trigger)  # pull trigger up
            pullTriggerDown = True
            print("I executed this")
        win.flip()
        if pullTriggerDown:
            win.callOnFlip(setParallelData, 0)
            pullTriggerDown = False
            print("I executed this as well")
    
    # Display a black screen with a white cross
    win.color = [0, 0, 0]  # Set background color to black, if you want gray its 0,0,0
    cross = visual.TextStim(win, text='+', color=[-1, -1, -1], height=0.1) #make a white cross in the middle of the screen
    cross.draw()
    win.flip()
    
    # wait until 'c' or 'f' key is pressed
    keys, time_key = event.waitKeys(keyList=('c', 'f'), timeStamped=True)[0]
    if keys == "c": keypress_trigger = "100"
    elif keys == "f": keypress_trigger = "200"
    else: keypress_trigger = "1"
    setParallelData(keypress_trigger)

    # get the time passed since reset
    react_time = time_key-time_flip_img
    print(react_time)
    
    return image_trigger, react_time, keypress_trigger, delay
    


# Interaction texts
start_str = """Welcome to our experiment!\n
In this experiment you are going to be shown a number of pictures including faces and other objects. All you have to do is take a good look and concentrate on how familiar the shown image is to you.\n
If you are ready press space to begin!"""

#mid_str =  """Let's start the experiment!\n
#Press the space bar whenever you are ready!"""

end_str = "The experiment is done. Thank you for your participation!"

KEYS_QUIT = ['escape','q']# Keys that quits the experiment

# Dialogue box to input user information
dialogue = gui.Dlg(title = "Where the f is F?")
dialogue.addFixedField("Participant ID: ", int(random.random()*1000000))
ages = list(range(16, 60))
dialogue.addField("Age: ", choices = ages)
dialogue.addField("Gender: ", choices = ["Female", "Male", "Other"])
dialogue.addField("Any Visual Impairment: ", choices = ["No", "Yes"])
dialogue.show()

if dialogue.OK: # Writing user information to variables ID, Age, Gender, Native Language
    ID = dialogue.data[0]
    Age = dialogue.data[1]
    Gender = dialogue.data[2]
    Visual_impairment = dialogue.data[3]
elif dialogue.Cancel:
    core.quit()
    

# get stimuli file names from folder
stimuli = glob("stimuli_images_test/*.png")


# randomize stimulus order
random.shuffle(stimuli)

columns = ["Timestamp","ID", "Age", "Gender", "Visual_impairment","Condition","Stimuli", "Accuracy", "Button_rt", "Set_delay_after", "Img_trigger", "Key_trigger"] #Preparing columns
logfile = pd.DataFrame(columns = columns) #Creating log file object

# Stop watch
stop_watch = core.Clock() #Defining stop watch
date = data.getDateStr() #Get date/time (to be used in logfiles)

# Intro Text
msg = visual.TextStim(win, text = start_str, font = "Times New Roman", bold = True, color = "black") #Defining msg
msg.draw() #Drawing msg
win.flip() #Showing msg
event.waitKeys(keyList = ["space"]) #Input keypress to continue

for stimulus in stimuli:
    Image_trigger, React_time, Keypress_trigger , delay = pic_and_react(stimulus, stop_watch)
    
    # Determine condition based on the first four characters of the stimulus name
    condition = stimulus[20:24]
    
    # Map the response key to "c" or "f"
    #Response = "c" if keys == "c" else "f"
    
    # Calculate accuracy based on conditions
    if Keypress_trigger == "100" and Image_trigger == "11":
        accuracy = 1
    elif Keypress_trigger == "200" and Image_trigger in ["22", "33", "44"]:
        accuracy = 1
    else:
        accuracy = 0
        
    
    
    # append data to logfile
    logfile = logfile.append({
        "Timestamp": date,
        "ID": ID,
        "Age": Age,
        "Gender": Gender,
        "Visual_impairment": Visual_impairment,
        "Condition": condition,  # Add the new column for condition
        "Stimuli": stimulus[20:26],
        "Accuracy": accuracy,
        "Button_rt": React_time,
        "Set_delay_after": delay,
        "Img_trigger": Image_trigger,
        "Key_trigger":Keypress_trigger
    }, ignore_index=True)
    
    keys = event.getKeys()
    for key in keys:
        if key in KEYS_QUIT:
            core.quit()


# Saving results as actual logfile.csv
logfile_name = "logfiles/logfile_{}_{}.csv".format(ID, date) #Defining .csv-filename from user ID and date of completion
logfile.to_csv(logfile_name) #Writing logfile object to logfile.csv

# Outro Text  
msg = visual.TextStim(win, text = end_str, font = "Times New Roman", bold = True, color = "black") #Shell
msg.draw() #Drawing msg
win.flip() #Showing msg
event.waitKeys(keyList = ["space", "escape"]) #Input keypress to end program